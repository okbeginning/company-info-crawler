import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime, timedelta
import time
import random
import json
import os

class StockCrawler:
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36',
            "Accept": "*/*",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Connection": "keep-alive",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Origin": "http://www.cninfo.com.cn",
            "Referer": "http://www.cninfo.com.cn/new/disclosure"
        }
        # 胜宏科技的股票代码
        self.stock_code = '300476'
        self.base_url = 'http://www.cninfo.com.cn/new/hisAnnouncement/query'
        
    def get_announcements(self, page=1):
        # 计算三年前的日期
        end_date = datetime.now()
        start_date = end_date - timedelta(days=3*365)
        
        data = {
            'stock': f'{self.stock_code},sz{self.stock_code}',
            'tabName': 'fulltext',
            'pageSize': 30,
            'pageNum': page,
            'column': 'szse',
            'category': 'category_ndbg_szsh;category_bndbg_szsh;category_yjdbg_szsh;category_sjdbg_szsh',  # 年报、半年报、季报
            'plate': 'sz',
            'searchkey': "",
            'secid': "",
            'sortName': "",
            'sortType': "",
            'seDate': f'{start_date.strftime("%Y-%m-%d")}~{end_date.strftime("%Y-%m-%d")}'
        }
        
        try:
            # 添加随机延时
            time.sleep(random.uniform(1, 3))
            
            response = requests.post(self.base_url, headers=self.headers, data=data)
            print(f"API响应状态码: {response.status_code}")
            print(f"API响应内容: {response.text[:200]}...")  # 打印前200个字符
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"请求失败，状态码：{response.status_code}")
                return None
        except Exception as e:
            print(f"发生错误：{str(e)}")
            return None

    def parse_announcements(self, json_data):
        if not json_data or 'announcements' not in json_data:
            return []
        
        announcements = []
        for ann in json_data['announcements']:
            announcement = {
                '标题': ann['announcementTitle'],
                '发布时间': datetime.fromtimestamp(ann['announcementTime']/1000).strftime('%Y-%m-%d'),
                '下载链接': f'http://static.cninfo.com.cn/{ann["adjunctUrl"]}',
                '公告类型': ann['announcementType']
            }
            announcements.append(announcement)
        return announcements

    def crawl(self):
        all_announcements = []
        page = 1
        
        while True:
            print(f"正在爬取第{page}页...")
            json_data = self.get_announcements(page)
            
            if not json_data or not json_data['announcements']:
                break
                
            announcements = self.parse_announcements(json_data)
            all_announcements.extend(announcements)
            
            if len(announcements) < 30:  # 如果返回的公告数少于30，说明是最后一页
                break
                
            page += 1
            time.sleep(random.uniform(1, 2))  # 添加随机延时
        
        # 将结果保存为CSV文件
        df = pd.DataFrame(all_announcements)
        df.to_csv('胜宏科技财报公告.csv', index=False, encoding='utf-8-sig')
        print(f"爬取完成，共获取{len(all_announcements)}条公告")
        return all_announcements

def get_financial_reports():
    # 创建保存文件的目录
    save_dir = "financial_reports"
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    
    # 东方财富网的API
    url = "https://np-anotice-stock.eastmoney.com/api/security/ann"
    
    # 请求头
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Accept": "*/*",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Referer": "https://np-anotice-stock.eastmoney.com/"
    }
    
    # 请求参数
    params = {
        "sr": -1,  # 按时间倒序
        "page_size": 50,
        "page_index": 1,
        "ann_type": "A",  # A表示年报
        "stock_list": "300476",  # 胜宏科技的股票代码
        "f_node": "1",  # 财务报告
        "rt": int(time.time() * 1000)
    }
    
    try:
        # 添加随机延时
        time.sleep(random.uniform(1, 3))
        
        response = requests.get(url, headers=headers, params=params)
        print(f"API响应状态码: {response.status_code}")
        
        data = response.json()
        
        if data.get('data', {}).get('list'):
            reports = data['data']['list']
            print(f"\n找到 {len(reports)} 份公告")
            
            # 创建一个DataFrame来存储报告信息
            reports_data = []
            
            for report in reports:
                title = report['title']
                notice_date = report.get('notice_date')
                
                if notice_date:
                    try:
                        # 解析日期字符串
                        if isinstance(notice_date, str):
                            date = datetime.strptime(notice_date.split()[0], '%Y-%m-%d')
                        else:
                            date = datetime.fromtimestamp(notice_date/1000)
                        
                        # 只下载近三年的报告
                        if (datetime.now() - date).days > 3*365:
                            continue
                            
                        # 仅下载标题中包含"季度报告"、"年度报告"或"半年度报告"的文件
                        if any(keyword in title for keyword in ["季度报告", "年度报告", "半年度报告"]):
                            download_url = f"https://pdf.dfcfw.com/pdf/H2_{report['art_code']}_1.pdf"
                            
                            # 添加随机延时
                            time.sleep(random.uniform(1, 2))
                            
                            # 下载PDF文件
                            pdf_response = requests.get(download_url, headers=headers)
                            if pdf_response.status_code == 200:
                                filename = os.path.join(save_dir, f"{title}_{date.strftime('%Y%m%d')}.pdf")
                                with open(filename, 'wb') as f:
                                    f.write(pdf_response.content)
                                print(f"已下载: {filename}")
                                
                                reports_data.append({
                                    '标题': title,
                                    '发布日期': date.strftime('%Y-%m-%d'),
                                    '文件路径': filename
                                })
                    except (ValueError, TypeError) as e:
                        print(f"处理日期时出错 ({notice_date}): {str(e)}")
                        continue
            
            # 保存报告信息到Excel
            if reports_data:
                df = pd.DataFrame(reports_data)
                excel_path = os.path.join(save_dir, '财务报告清单.xlsx')
                df.to_excel(excel_path, index=False)
                print(f"\n报告清单已保存到: {excel_path}")
            else:
                print("\n未找到近三年内的财务报告")
            
        else:
            print("未找到任何财务报告")
            
    except Exception as e:
        print(f"发生错误: {str(e)}")

if __name__ == "__main__":
    crawler = StockCrawler()
    crawler.crawl()
    get_financial_reports()
